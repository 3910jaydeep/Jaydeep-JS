

var x = 5;
document.write(x, "\n");


let y = 10;
document.write(y, "\n");


document.write(z, "\n");
var z = 2;

document.write(a);
let a = 3;

const c = 3;
c=10;
document.write(c);
c=100;
document.write(c);