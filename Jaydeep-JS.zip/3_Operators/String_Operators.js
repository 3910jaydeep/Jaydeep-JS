let s1 = "Jaydeep";
let s2 = "Joshi";
let s3 = s1 + " " + s2;
document.write(s3);